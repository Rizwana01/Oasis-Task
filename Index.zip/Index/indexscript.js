function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    
    if (username === "admin" && password === "password") {
        alert("Login successful!");
    } else {
        alert("Invalid credentials. Please try again.");
    }
}

document.addEventListener("DOMContentLoaded", () => {
    const jobListings = [
        { title: "Software Engineer", company: "Tech Corp", location: "New York" },
        { title: "Web Developer", company: "Web Solutions", location: "San Francisco" }
    ];
    
    const jobListContainer = document.getElementById("job-listings");
    
    jobListings.forEach(job => {
        const jobItem = document.createElement("div");
        jobItem.innerHTML = `<h3>${job.title}</h3><p>${job.company} - ${job.location}</p>`;
        jobListContainer.appendChild(jobItem);
    });
});
